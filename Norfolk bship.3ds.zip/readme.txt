-- 3dvia.com   --

The zip file Norfolk bship.3ds.zip contains the following files :
- readme.txt
- Norfolk bship.3ds


-- Model information --

Model Name : Norfolk bship
Author : Pham hong Kien
Publisher : thapdien05

You can view this model here :
http://www.3dvia.com/content/B9B59DAF8193A5B7
More models about this author :
http://www.3dvia.com/thapdien05


-- Attached license --

A license is attached to the Norfolk bship model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-nc-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
